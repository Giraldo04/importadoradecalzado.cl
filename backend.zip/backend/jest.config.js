// jest.config.js
module.exports = {
    testEnvironment: 'node',
  };
  